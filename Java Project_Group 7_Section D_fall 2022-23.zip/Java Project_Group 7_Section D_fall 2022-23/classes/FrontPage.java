package classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FrontPage
{
	ImageIcon cover;
	JPanel header;
	JLabel name;
	JLabel title;
	JButton login;
	
	public FrontPage()
	{
		//frame creation
		JFrame frame = new JFrame();
	    frame.setSize(800,500);
		
		//adding background
		cover = new ImageIcon("./photos/fleur.jpg");
		Image img = cover.getImage();
		Image temp_img = img.getScaledInstance(800,500,Image.SCALE_SMOOTH);
		cover = new ImageIcon(temp_img);
	    JLabel back_img = new JLabel("", cover, JLabel.CENTER);
	    back_img.setBounds(0,0,800,500);
		//back_img.setLayout(null);
	    //back_img.setVisible(true);
	    frame.add(back_img);
		
		//font1
		Font f1 = new Font("Freestyle Script", Font.BOLD, 32);
		Font f2 = new Font("Times New Roman", Font.PLAIN, 24);
		
		
		//heading
		header = new JPanel();
		header.setLayout(null);
		header.setBackground(new Color(0,0,0,80));
		header.setBounds(0,0,800,100);
		back_img.add(header);
		
		
		//title
		name = new JLabel("FLEUR");
		//l1.setOpaque(true);
		name.setForeground(Color.WHITE);
		name.setBounds(368, 25, 400, 50);
		name.setFont(f1);
		header.add(name);
		
		title = new JLabel("online book shop");
		//l1.setOpaque(true);
		title.setForeground(Color.WHITE);
		title.setBounds(320, 60, 400, 50);
		title.setFont(f2);
		header.add(title);
		
		
		
		//font3
		Font f3 = new Font("Arial", Font.BOLD, 14);
		
		//Buttons
		//get started
		login = new JButton("Get Started");
		
		login.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mousePressed(MouseEvent e)
			{
				new GetStarted();
        		frame.setVisible(false);
			}
		});
		login.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		login.setBackground(new Color(212,175,55));
		login.setForeground(Color.BLACK);
		login.setBounds(300, 240, 195, 25);
		login.setFont(f3);
		back_img.add(login);
		
		/*//privacy policy
		b2 = new JButton("Privacy Policy");
		b2.setBackground(new Color(212,175,55));
		b2.setForeground(Color.BLACK);
		b2.setBounds(300, 300, 195, 25);
		b2.setFont(f3);
		back_img.add(b2);*/
		
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
	    frame.setVisible(true);
	    frame.setLayout(null);
	}
	public static void main (String [] args ){
		
		new FrontPage();	
	}
	
}