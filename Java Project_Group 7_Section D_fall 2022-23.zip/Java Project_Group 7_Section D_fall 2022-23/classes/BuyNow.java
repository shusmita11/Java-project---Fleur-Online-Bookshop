package classes;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.Font;
import java.awt.event.*;
import java.awt.Color;
import java.util.*;
import java.awt.Cursor;
import javax.swing.border.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import static javax.swing.JOptionPane.showMessageDialog;

public class BuyNow   {
	
    JLabel J_Flure,J_favourite,Card,Online, Name, Expiration,CVV,Show_pic;
    JButton Confirm ;
    JTextField T_Card, T_Name, T_Expiration, T_CVV;
  
	double ans;
	double value=0;
	
	public BuyNow( ){
////Frame	
      JFrame frame= new JFrame();
      frame.setLayout(null);
      frame.setSize(1100, 700);
		
		
	Font f1 =new Font ( "Freestyle Script",Font.BOLD,50);
    Font f2 =new Font ( "Harlow Solid Italic",Font.PLAIN,24);
    Font f3 =new Font ( "Times New Roman",Font.PLAIN,30);
    Font f4 =new Font ( "Times New Roman",Font.PLAIN,20);
		
		
    J_Flure = new JLabel( "Fleur Bookshop");
	    J_Flure.setForeground(new Color(212,175,55));
        J_Flure.setBounds(700, 0, 800, 80);
        J_Flure.setFont(f1);
        frame.add(J_Flure);


    J_favourite = new JLabel( "get your favourite books right now!");
	    J_favourite.setForeground(new Color(0,5,0));
        J_favourite.setBounds(655, 30, 750, 80);
        J_favourite.setFont(f2);
        frame.add(J_favourite);

    Online = new JLabel( "Online Payment");
	    Online.setForeground(new Color(0,5,0));
        Online.setBounds(700,90, 750, 80);
        Online.setFont(f3);
        frame.add(Online);
 

    Card = new JLabel("*Card number");
        Card.setBounds(600, 180, 150, 40);
        Card.setFont(new Font("Serif", Font.PLAIN, 20));

    Name = new JLabel("*Name on card");
        Name.setBounds(600, 260, 150, 40);
        Name.setFont(new Font("Serif", Font.PLAIN, 20));

    Expiration = new JLabel("*Expiration date");
        Expiration.setBounds(600, 350, 150, 40);
        Expiration.setFont(new Font("Serif", Font.PLAIN, 20));

    CVV = new JLabel("*CVV");
        CVV.setBounds(600, 430, 100, 40);
        CVV.setFont(new Font("Serif", Font.PLAIN, 20));

// Lable add
        frame.add(Card);
        frame.add(Name);
        frame.add(Expiration);
        frame.add(CVV);

    

// JTextField

        T_Card = new JTextField();
        T_Card.setBounds(600, 220, 400, 40);
        T_Card.setFont(new Font("Serif", Font.PLAIN, 18));

        T_Name = new JTextField();
        T_Name.setBounds(600, 300, 400, 40);
        T_Name.setFont(new Font("Serif", Font.PLAIN, 18));

        T_Expiration = new JTextField();
        T_Expiration.setBounds(600,390, 200, 40);
        T_Expiration.setFont(new Font("Serif", Font.PLAIN, 18));

        T_CVV= new JTextField();
        T_CVV.setBounds(600, 470, 150, 40);
        T_CVV.setFont(new Font("Serif", Font.PLAIN, 18));
		
////text field add
        frame.add(T_Card);
        frame.add(T_Name);
        frame.add(T_Expiration);
        frame.add(T_CVV);

//////////file read and value update

	  
	 ///button 
	  
    Confirm = new JButton( "Confirm" );// shorashori payment e jabe 
	
       Confirm .addMouseListener(new MouseAdapter()

        {

            //Override

            public void mouseClicked(MouseEvent e)

            {
		
		
		
		
                   String s_First =T_Card .getText(); 	   
                   String s_Second =  T_Name.getText(); 
                   String s_Third = T_Expiration .getText(); 
                   String s_Forth =  T_CVV.getText(); 

				  if ( s_First.isEmpty()|| s_Second.isEmpty()||s_Third.isEmpty()||s_Forth.isEmpty() )
                  {
                     JOptionPane.showMessageDialog(null, "Please fill up all the fildes", "Warning!", JOptionPane.WARNING_MESSAGE);
                  }  
				   
                  else
				  {
                   JOptionPane.showMessageDialog(null, "Thanks for Shoping ",  "Fleur book shop", JOptionPane.WARNING_MESSAGE);     
                  }
			}
		
                 
		});
	    Confirm.setForeground(Color.black);
	    Confirm.setForeground(new Color(5, 102, 14));
        Confirm.setBounds(730, 540, 150, 40);
		Confirm.setBackground(new Color(212,175,55)); 
        Confirm.setFont(f4);
        Confirm.setFocusPainted(false);
        frame.add(Confirm);//button add
		
		
		
		
		
				
	  

ImageIcon Main_image = new ImageIcon("./photos/Payment.png");
Image For_Edith_image,Done_Image ;
For_Edith_image=Main_image.getImage();
Done_Image= For_Edith_image.getScaledInstance(500,700,Image.SCALE_SMOOTH);
Main_image=new ImageIcon (Done_Image);

Show_pic= new JLabel ("",Main_image,SwingConstants.LEFT);
Show_pic.setBounds(0,0,600,700);
frame.add(Show_pic);

		
		
		
		JButton  back =new JButton();
		
		
		back = new JButton();
		
		back.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{   //new UserDashboard();
        		frame.setVisible(false);
			}
		});
		back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
        back.setIcon(new ImageIcon("./photos/back.png"));
		back.setBackground(new Color(255,255,255));
        back.setBounds(10, 2, 25, 25);
        back.setFocusPainted(false);
		Show_pic.add(back);
		
		
	  

	  
	  
	  
    frame.  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.  setLocationRelativeTo(null);
    frame.  setVisible(true);
    frame.  setResizable(false);
		
			}
			
			
public static void main (String []args)
{
 new BuyNow();


}
	
	
			
	}
		
	
	

	
	
	
	