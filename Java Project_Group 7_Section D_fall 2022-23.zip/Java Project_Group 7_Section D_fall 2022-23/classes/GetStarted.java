package classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import static javax.swing.JOptionPane.showMessageDialog;
import java.io.*;
import java.nio.file.*;
import java.util.*;


public class GetStarted
{
	JFrame frame;
	JPanel bkgpanel;
	JLabel intro;
	JLabel signUp;
	JLabel adlogin;
	JPanel lgnpanel;
	JLabel lgntitle;
	ImageIcon image;
	JLabel uname;
	JLabel pword;
	JTextField user;
	JPasswordField pass;
	JRadioButton ruser;
	JRadioButton radmin;
    JButton lgnBtn;
    JButton bkBtn;
	JToggleButton showpass;
	ImageIcon open;
	ImageIcon close;
	JButton exitB;
	JButton minB;
	JButton backB;
	JLabel forgotpass;
	
	public GetStarted()
	{
		//frame creation
		frame = new JFrame("Login page");
		//frame.setBackground(Color.BLUE);
	    frame.setSize(800,500);
		//frame.getContentPane().setBackground(new Color(255, 255, 255));
		//135,206,235
		//245,223,104
		
		//font
		Font f1 = new Font("Times New Roman", Font.BOLD, 24);
		Font f2 = new Font("Times New Roman", Font.PLAIN, 18);
		Font f3 = new Font("Times New Roman", Font.PLAIN, 14);
		Font f4 = new Font("Harlow Solid Italic", Font.PLAIN, 26);
		Font f5 = new Font("Freestyle Script", Font.BOLD, 38);
	
		
		//creating background panel 
		bkgpanel = new JPanel();
		bkgpanel.setVisible(true);
		bkgpanel.setLayout(null);
		bkgpanel.setBackground(new Color(255,255,255));
		bkgpanel.setBounds(300,0,500,500);
		frame.add(bkgpanel);
		
		//exit button
		exitB = new JButton();
		
		exitB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				  frame.setVisible(false);
			}
		});
		exitB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		exitB.setIcon(new ImageIcon("./photos/exit.png"));
		exitB.setBackground(new Color(255,255,255));
        exitB.setBounds(400, 2, 25, 25);
        exitB.setFocusPainted(false);
        exitB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        exitB.setContentAreaFilled(false);
		bkgpanel.add(exitB);

        //minimize button
        minB = new JButton();
		
		minB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				   frame.setState(Frame.ICONIFIED);
			}
		});
		minB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		minB.setIcon(new ImageIcon("./photos/min.png"));
		minB.setBackground(new Color(0,0,0));
        minB.setBounds(440, 2, 24, 24);
        minB.setFocusPainted(false);
        minB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        minB.setContentAreaFilled(false);
		bkgpanel.add(minB);
		
		//back button
		backB = new JButton();
		
		backB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new FrontPage();
        		frame.setVisible(false);
			}
		});
		backB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
        backB.setIcon(new ImageIcon("./photos/back.png"));
		backB.setBackground(new Color(255,255,255));
        backB.setBounds(10, 2, 25, 25);
        backB.setFocusPainted(false);
        backB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        backB.setContentAreaFilled(false);
		bkgpanel.add(backB);
		
		//back Button
		/*bkBtn = new JButton("back");
		
		bkBtn.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new FrontPage();
        		frame.setVisible(false);
			}
		});
		bkBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		bkBtn.setForeground(new Color(3,37,126));
		bkBtn.setBackground(new Color(128,128,128));
		bkBtn.setBounds(390, 10, 65, 20);
		bkgpanel.add(bkBtn);*/
		
		//title labels
		intro = new JLabel("FLEUR online Bookshop");
		intro.setForeground(new Color(212,175,55));
		intro.setBounds(110, 30, 400, 30);
		intro.setFont(f5);
		bkgpanel.add(intro);
		
		//intro labels
		intro = new JLabel("Get your favourite books right now!");
		intro.setForeground(Color.BLACK);
		intro.setBounds(60, 70, 400, 30);
		intro.setFont(f4);
		bkgpanel.add(intro);
		
		//signup labels
		intro = new JLabel("Don't have any account?");
		intro.setForeground(new Color(0,0,0));
		intro.setBounds(122, 380, 200, 30);
		intro.setFont(f2);
		bkgpanel.add(intro);
		
		//signUP link
		signUp = new JLabel("Sign UP");
		
		signUp.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new Sign_Up();
        		frame.setVisible(false);
			}
		});
		signUp.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		signUp.setForeground(new Color(135,206,235));
		signUp.setBounds(308, 380, 100, 30);
		signUp.setFont(f2);
		bkgpanel.add(signUp);
		
		adlogin = new JLabel("Go to admin login");
		adlogin.setForeground(new Color(128,128,0));
		adlogin.setBounds(190, 405, 200, 30);
		adlogin.setFont(f2);
		adlogin.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new Admin();
        		frame.setVisible(false);
			}
		});
		adlogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		bkgpanel.add(adlogin);
		
		
		//creating login panel
		lgnpanel = new JPanel();
		lgnpanel.setVisible(true);
		lgnpanel.setLayout(null);
		lgnpanel.setBackground(new Color(128,128,128));
		lgnpanel.setBounds(70, 150, 340, 230);
		bkgpanel.add(lgnpanel);
		
		//title
		lgntitle = new JLabel("LOGIN");
		//lgntitle.setOpaque(true);
		lgntitle.setForeground(Color.BLACK);
		lgntitle.setBounds(135, 10, 200, 50);
		lgntitle.setFont(f1);
		lgnpanel.add(lgntitle);
		
		// creating JLabels
		uname = new JLabel("Username:");
		uname.setForeground(Color.BLACK);
		uname.setBounds(50, 60, 95, 50);
		uname.setFont(f2);
		lgnpanel.add(uname);
		
		pword = new JLabel("Password:");
		pword.setForeground(Color.BLACK);
		pword.setBounds(50, 100, 95, 50);
		pword.setFont(f2);
		lgnpanel.add(pword);
		
		/*forgotpass = new JLabel("forgot password?");
		forgotpass.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new SignUp();
        		frame.setVisible(false);
			}
		});
		forgotpass.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		forgotpass.setForeground(new Color(192,192,192));
		forgotpass.setBounds(160, 125, 145, 50);
		forgotpass.setFont(f3);
		lgnpanel.add(forgotpass);*/
	
		
		//creating fields
		user = new JTextField();
		user.setBackground(new Color(192,192,192));
		user.setBounds(155, 75, 135, 25);
		lgnpanel.add(user);
		
		pass = new JPasswordField();
		pass.setBackground(new Color(192,192,192));
		pass.setBounds(155, 115, 135, 25);
		lgnpanel.add(pass);
		
		open = new ImageIcon("./photos/open.png");
		close = new ImageIcon("./photos/close.png");
		showpass = new JToggleButton(close);
		showpass.setBounds(295, 115, 24, 24);
		showpass.setBackground(new Color(0,0,0));
		showpass.setForeground(new Color(0,0,0));
		showpass.setOpaque(false);
		showpass.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
		showpass.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				//String pword = pass.getText();
				if(showpass.isSelected())
				{
					showpass.setIcon(open);
					pass.setEchoChar((char)0);
				}
				
				else
				{
					showpass.setIcon(close);
					pass.setEchoChar('*');
				}
			}
		});
		showpass.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		lgnpanel.add(showpass);
		
		
		/*//radio buttons
		ruser = new JRadioButton("login as user");
		//lgnBtn.setBackground(new Color(135,206,235));
		ruser.setBackground(new Color(128,128,128));
        ruser.setBounds(65, 160, 85, 12);
	    ruser.setFont(f3);
		lgnpanel.add(ruser);
		
		
		radmin = new JRadioButton("login as admin");
		//lgnBtn.setBackground(new Color(135,206,235));
		radmin.setBackground(new Color(128,128,128));
        radmin.setBounds(175, 160, 92, 12);
	    radmin.setFont(f3);
		lgnpanel.add(radmin);
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(ruser);
		bg.add(radmin);*/
		
		//button
		
		//login button
		lgnBtn = new JButton("Login");
		lgnBtn.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				String username = user.getText();
				String password = pass.getText();
				
				boolean uEmpty = username.isEmpty();
				boolean pEmpty = password.isEmpty();
				
				String u = "User Name: "+username;
				String p = "password : "+password;
				
				if(uEmpty==true || pEmpty==true)
				{
					showMessageDialog(null, "please fillup the information","Warning", JOptionPane.WARNING_MESSAGE);
				}
				
				else
				{
					boolean booluser = false;
					try
					{
						FileReader fr = new FileReader(".\\Udata\\user_data.txt");
						BufferedReader fbr = new BufferedReader(fr);
						
						int allLine = 0;
						while(fbr.readLine()!=null)
						{
							allLine++;
						}
						fbr.close();
						
						for(int i=0; i<allLine; i++)
						{
							String line1 = Files.readAllLines(Paths.get(".\\Udata\\user_data.txt")).get(i);
							if(line1.equals(u)==true)
							{
								String line2 = Files.readAllLines(Paths.get(".\\Udata\\user_data.txt")).get(i+3);
								if(line2.equals(p))
								{
									booluser = true;
									new UserDashboard();
						            frame.setVisible(false);
									break;
								}
								
								else
								{
									booluser = false;
									showMessageDialog(null, "wrong password","Warning", JOptionPane.WARNING_MESSAGE);
								}
							}
							
							else
							{
								booluser = false;
								//showMessageDialog(null, "wrong","Warning", JOptionPane.WARNING_MESSAGE);
							}
						}
						
						if(booluser==false)
						{
							showMessageDialog(null, "not found","Warning", JOptionPane.WARNING_MESSAGE);
						}
					}
						
					catch(Exception ei)
					{
						System.out.println(ei);
					}
					
					/*if(booluser=true)
					{
						new FrontPage();
						frame.setVisible(false);
					}
					
					else
					{
						JOptionPane.showMessageDialog(frame, "Wrong");
					}*/
				}
			}
		});
		
		lgnBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		lgnBtn.setBackground(new Color(192,192,192));
		lgnBtn.setBounds(120, 180, 100, 20);
		lgnpanel.add(lgnBtn);
		
		
		//adding background
		image = new ImageIcon("./photos/loginpage.png");
		Image img = image.getImage();
		Image temp_img = img.getScaledInstance(300,500,Image.SCALE_SMOOTH);
		image = new ImageIcon(temp_img);
	    JLabel back_img = new JLabel("", image, SwingConstants.LEFT);
	    back_img.setBounds(0,0,300,500);
		frame.add(back_img);
		//back_img.setLayout(null);
	    //back_img.setVisible(true);
		
		
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setVisible(true);
	    frame.setLayout(null);
		
	}
	
	public static void main (String [] args ){
		
		new GetStarted();	
	}	
}

