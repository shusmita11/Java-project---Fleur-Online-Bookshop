package classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import static javax.swing.JOptionPane.showMessageDialog;

public class TextBook
{
	JFrame frame;
	JPanel backpanel;
	JPanel intropanel;
	JButton userB;
	JLabel user;
	JButton exitB;
	JButton minB;
	JButton backB;
	JLabel intro, text;
	JButton textB1, textB2, textB3, textB4, textB5, textB6, textB7, textB8;
	//JLabel name1, isbn1, author1, price1, name2, isbn2, author2, price2, name3, isbn3, author3, price3, name4, isbn4, author4, price4, name5, isbn5, author5, price5, 
	JLabel name1, price1;
	JLabel name2, price2;
	JLabel name3, price3;
	JLabel name4, price4;
	JLabel name5, price5;
	JLabel name6, price6;
	JLabel name7, price7;
	JLabel name8, price8;
	
	
	public TextBook()
	{
		frame = new JFrame();
	    frame.setLayout(null);
		
	    frame.setSize(1300,700);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//font
		Font f1 = new Font("Harlow Solid Italic", Font.PLAIN, 20);
		Font f2 = new Font("Freestyle Script", Font.BOLD, 38);
		Font f3 = new Font("Times New Roman", Font.BOLD, 24);
		Font f4 = new Font("Times New Roman", Font.PLAIN, 18);
		Font f5 = new Font("Times New Roman", Font.PLAIN, 14);
		Font f6 = new Font("Harlow Solid Italic", Font.PLAIN, 30);
		
		//background panel
		backpanel = new JPanel();
	    backpanel.setBackground(new Color(192,192,192));
	    backpanel.setBounds(0,0,1300,700);
	    backpanel.setVisible(true);
	    backpanel.setLayout(null);
		frame.add(backpanel);
		
		//intro panel
		intropanel = new JPanel();
	    intropanel.setBackground(new Color(255,255,255));
	    intropanel.setBounds(0,0,1300,100);
	    intropanel.setVisible(true);
	    intropanel.setLayout(null);
		backpanel.add(intropanel);
		
		
		/*//accountbutton
		userB = new JButton();
        userB.setIcon(new ImageIcon("./photos/account.png"));
		userB.setBackground(new Color(255,255,255));
        userB.setBounds(1100,20,55,55);
		userB.setFocusPainted(false);
        userB.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        userB.setContentAreaFilled(false);
		intropanel.add(userB);
		
		//username
		user = new JLabel("user");
		user.setForeground(Color.BLACK);
		user.setBounds(1115, 77, 55, 16);
		user.setFont(f5);
		intropanel.add(user);*/
		
		//exit button
		exitB = new JButton();
		
		exitB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				  frame.setVisible(false);
			}
		});
		exitB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		exitB.setIcon(new ImageIcon("./photos/exit.png"));
		exitB.setBackground(new Color(255,255,255));
        exitB.setBounds(1230, 2, 25, 25);
        exitB.setFocusPainted(false);
        exitB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        exitB.setContentAreaFilled(false);
		intropanel.add(exitB);

        //minimize button
        minB = new JButton();
		
		minB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				   frame.setState(Frame.ICONIFIED);
			}
		});
		minB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		minB.setIcon(new ImageIcon("./photos/min.png"));
		minB.setBackground(new Color(0,0,0));
        minB.setBounds(1190, 2, 24, 24);
        minB.setFocusPainted(false);
        minB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        minB.setContentAreaFilled(false);
		intropanel.add(minB);
		
		//back button
		backB = new JButton();
		
		backB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new UserDashboard();
        		frame.setVisible(false);
			}
		});
		backB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
        backB.setIcon(new ImageIcon("./photos/back.png"));
		backB.setBackground(new Color(255,255,255));
        backB.setBounds(10, 2, 25, 25);
        backB.setFocusPainted(false);
        backB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        backB.setContentAreaFilled(false);
		intropanel.add(backB);
		
		
		//title labels
		intro = new JLabel("FLEUR online Bookshop");
		intro.setForeground(new Color(212,175,55));
		intro.setBounds(510, 20, 400, 30);
		intro.setFont(f2);
		intropanel.add(intro);
		
		//intro labels
		intro = new JLabel("Get your favourite books right now!");
		intro.setForeground(Color.BLACK);
		intro.setBounds(500, 55, 400, 30);
		intro.setFont(f1);
		intropanel.add(intro);
		
		//category
		text = new JLabel("textbooks");
		text.setForeground(new Color(0,0,0));
		text.setBounds(570, 110, 170, 40);
		text.setFont(f6);
		backpanel.add(text);
		
		
		////////////////////////////////////////////////////////////
		//textbook1
		textB1 = new JButton();
        textB1.setIcon(new ImageIcon("./photos/textbook1.png"));
        textB1.setBounds(130,180,115,149);
		textB1.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new Textbook1();
        		frame.setVisible(false);
			}
		});
		textB1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(textB1);
		
		name1 = new JLabel("Java: The Complete Reference");
		name1.setForeground(new Color(0,0,0));
		name1.setBounds(100, 330, 220, 14);
		name1.setFont(f5);
		backpanel.add(name1);
		
		price1 = new JLabel("1880 tk");
		price1.setForeground(new Color(0,0,0));
		price1.setBounds(165, 345, 220, 14);
		price1.setFont(f5);
		backpanel.add(price1);
		
		
		////////////////////////////////////////////////////////
		//textbook2
		textB2 = new JButton();
        textB2.setIcon(new ImageIcon("./photos/textbook2.png"));
        textB2.setBounds(430,180,110,148);
		textB2.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new Textbook2();
        		frame.setVisible(false);
			}
		});
		textB2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(textB2);
		
		name2 = new JLabel("Discrete Mathematics and Its Applications");
		name2.setForeground(new Color(0,0,0));
		name2.setBounds(365, 330, 250, 14);
		name2.setFont(f5);
		backpanel.add(name2);
		
		price2 = new JLabel("2000 tk");
		price2.setForeground(new Color(0,0,0));
		price2.setBounds(465, 345, 220, 14);
		price2.setFont(f5);
		backpanel.add(price2);
		
		
		
		
		////////////////////////////////////////////////////////
		//storybook3
		textB3 = new JButton();
        textB3.setIcon(new ImageIcon("./photos/textbook3.png"));
        textB3.setBounds(730,180,112,149);
		textB3.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new Textbook3();
        		frame.setVisible(false);
			}
		});
		textB3.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(textB3);
		
		name3 = new JLabel("Calculus");
		name3.setForeground(new Color(0,0,0));
		name3.setBounds(762, 330, 220, 14);
		name3.setFont(f5);
		backpanel.add(name3);
		
		price3 = new JLabel("1800 tk");
		price3.setForeground(new Color(0,0,0));
		price3.setBounds(765, 345, 220, 14);
		price3.setFont(f5);
		backpanel.add(price3);
		

		////////////////////////////////////////////////////////
		//storybook4
		textB4 = new JButton();
        textB4.setIcon(new ImageIcon("./photos/textbook4.png"));
        textB4.setBounds(1030,180,112,148);
		textB4.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new Textbook4();
        		frame.setVisible(false);
			}
		});
		textB4.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(textB4);
		
		name4 = new JLabel("Fundamentals of Physics");
		name4.setForeground(new Color(0,0,0));
		name4.setBounds(1016, 330, 220, 16);
		name4.setFont(f5);
		backpanel.add(name4);
		
		price4 = new JLabel("1950 tk");
		price4.setForeground(new Color(0,0,0));
		price4.setBounds(1065, 345, 220, 14);
		price4.setFont(f5);
		backpanel.add(price4);
		
		
		
		///////////////////////////////////////////
		//storybook5
		textB5 = new JButton();
        textB5.setIcon(new ImageIcon("./photos/textbook5.png"));
        textB5.setBounds(130,405,115,147);
		textB5.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				showMessageDialog(null, "Not available","Warning", JOptionPane.WARNING_MESSAGE);
			}
		});
		textB5.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(textB5);
		
		name5 = new JLabel("Software Engeering");
		name5.setForeground(new Color(0,0,0));
		name5.setBounds(130, 555, 220, 16);
		name5.setFont(f5);
		backpanel.add(name5);
		
		price5 = new JLabel("1580 tk");
		price5.setForeground(new Color(0,0,0));
		price5.setBounds(160, 570, 220, 14);
		price5.setFont(f5);
		backpanel.add(price5);
		
		////////////////////////////////////////////////
		//storybook6
		textB6 = new JButton();
        textB6.setIcon(new ImageIcon("./photos/textbook6.png"));
        textB6.setBounds(430,405,100,149);
		textB6.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				showMessageDialog(null, "Not available","Warning", JOptionPane.WARNING_MESSAGE);
			}
		});
		textB6.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(textB6);
		
		name6 = new JLabel("Discrete Mathematics-An Open Introduction");
		name6.setForeground(new Color(0,0,0));
		name6.setBounds(355, 555, 250, 15);
		name6.setFont(f5);
		backpanel.add(name6);
		
		price6 = new JLabel("1600 tk");
		price6.setForeground(new Color(0,0,0));
		price6.setBounds(458, 570, 220, 14);
		price6.setFont(f5);
		backpanel.add(price6);
		
		
		//storybook7
		textB7 = new JButton();
        textB7.setIcon(new ImageIcon("./photos/textbook7.png"));
        textB7.setBounds(735,405,105,137);
		textB7.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				showMessageDialog(null, "Not available","Warning", JOptionPane.WARNING_MESSAGE);
			}
		});
		textB7.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(textB7);
		
		name7 = new JLabel("Differential Equations");
		name7.setForeground(new Color(0,0,0));
		name7.setBounds(725, 555, 220, 16);
		name7.setFont(f5);
		backpanel.add(name7);
		
		price7 = new JLabel("2050 tk");
		price7.setForeground(new Color(0,0,0));
		price7.setBounds(765, 570, 220, 14);
		price7.setFont(f5);
		backpanel.add(price7);
		
		
		
		//////////////////////////////////////////////////////
		//storybook8
		textB8 = new JButton();
        textB8.setIcon(new ImageIcon("./photos/textbook8.png"));
        textB8.setBounds(1030,405,100,151);
		textB8.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				showMessageDialog(null, "Not available","Warning", JOptionPane.WARNING_MESSAGE);
			}
		});
		textB8.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(textB8);
		
		name8 = new JLabel("Seven Brief Lessons On Physics");
		name8.setForeground(new Color(0,0,0));
		name8.setBounds(990, 555, 220, 16);
		name8.setFont(f5);
		backpanel.add(name8);
		
		price8 = new JLabel("1760 tk");
		price8.setForeground(new Color(0,0,0));
		price8.setBounds(1060, 570, 220, 14);
		price8.setFont(f5);
		backpanel.add(price8);
		
		
		
		frame.setVisible(true);
        frame.setLocationRelativeTo(null);
		frame.setResizable(false);
	}
	
	
	
	
	
	//main method
	public static void main (String [] args )
	{
		
		new TextBook();	
	}	
}