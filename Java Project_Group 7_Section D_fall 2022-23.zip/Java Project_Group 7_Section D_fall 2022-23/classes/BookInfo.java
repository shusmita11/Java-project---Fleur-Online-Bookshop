package classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import static javax.swing.JOptionPane.showMessageDialog;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class BookInfo
{
	JFrame frame;
	JPanel bkgpanel;
	JPanel intropanel;
	JLabel intro;
	JLabel name;
	JLabel isbn;
	JTextField bookname;
	JTextField bookisbn;
	JButton insertB;
	JButton exitB;
	JButton minB;
	JButton backB;
	
	public BookInfo()
	{
		frame = new JFrame();
	    frame.setLayout(null);
		
	    frame.setSize(600,400);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//font
		Font f1 = new Font("Harlow Solid Italic", Font.PLAIN, 20);
		Font f2 = new Font("Freestyle Script", Font.BOLD, 38);
		Font f3 = new Font("Times New Roman", Font.BOLD, 24);
		Font f4 = new Font("Times New Roman", Font.PLAIN, 18);
		Font f5 = new Font("Times New Roman", Font.PLAIN, 16);
		
		//background panel
		JPanel backpanel = new JPanel();
	    backpanel.setBackground(new Color(192,192,192));
	    backpanel.setBounds(0,0,600,400);
	    backpanel.setVisible(true);
	    backpanel.setLayout(null);
		frame.add(backpanel);
		
		//intro panel
        intropanel = new JPanel();
	    intropanel.setBackground(new Color(255,255,255));
	    intropanel.setBounds(0,0,600,100);
	    intropanel.setVisible(true);
	    intropanel.setLayout(null);
		backpanel.add(intropanel);
		
		//title labels
		intro = new JLabel("FLEUR online Bookshop");
		intro.setForeground(new Color(212,175,55));
		intro.setBounds(155, 20, 400, 30);
		intro.setFont(f2);
		intropanel.add(intro);
		
		//intro labels
		intro = new JLabel("Get your favourite books right now!");
		intro.setForeground(Color.BLACK);
		intro.setBounds(145, 60, 400, 30);
		intro.setFont(f1);
		intropanel.add(intro);
		
		//exit button
		exitB = new JButton();
		
		exitB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				  frame.setVisible(false);
			}
		});
		exitB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		exitB.setIcon(new ImageIcon("./photos/exit.png"));
		exitB.setBackground(new Color(255,255,255));
        exitB.setBounds(540, 2, 25, 25);
        exitB.setFocusPainted(false);
        exitB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        exitB.setContentAreaFilled(false);
		intropanel.add(exitB);

        //minimize button
        minB = new JButton();
		
		minB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				   frame.setState(Frame.ICONIFIED);
			}
		});
		minB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		minB.setIcon(new ImageIcon("./photos/min.png"));
		minB.setBackground(new Color(0,0,0));
        minB.setBounds(500, 2, 24, 24);
        minB.setFocusPainted(false);
        minB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        minB.setContentAreaFilled(false);
		intropanel.add(minB);
		
		//back button
		backB = new JButton();
		
		backB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				new AdminDashboard();
        		frame.setVisible(false);
			}
		});
		backB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
        backB.setIcon(new ImageIcon("./photos/back.png"));
		backB.setBackground(new Color(255,255,255));
        backB.setBounds(10, 2, 25, 25);
        backB.setFocusPainted(false);
        backB.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        backB.setContentAreaFilled(false);
		intropanel.add(backB);
		
		//book name
		name = new JLabel("Book Name: ");
		name.setForeground(new Color(0,0,0));
		name.setBounds(100, 140, 100, 30);
		name.setFont(f4);
		backpanel.add(name);
		
		bookname = new JTextField();
		bookname.setBackground(new Color(255,255,255));
		bookname.setBounds(200, 140, 270, 30);
		backpanel.add(bookname);
		
		//book isbn
		isbn = new JLabel("Book ISBN: ");
		isbn.setForeground(new Color(0,0,0));
		isbn.setBounds(100, 190, 100, 30);
		isbn.setFont(f4);
		backpanel.add(isbn);
		
		bookisbn = new JTextField();
		bookisbn.setBackground(new Color(255,255,255));
		bookisbn.setBounds(200, 190, 270, 30);
		backpanel.add(bookisbn);
		
		/////////////////////////////////////////////////////////////////////////////
		//insert button
		insertB = new JButton("Insert");
		insertB.setBackground(new Color(128,128,128));
        insertB.setBounds(225,250,150,30);
		insertB.addMouseListener(new MouseAdapter()
		{
			//Override
			public void mouseClicked(MouseEvent e)
			{
				//new FrontPage();
        		//frame.setVisible(false);
				
				  String isbn = bookisbn.getText(); 
			     String bname = bookname.getText(); 
				 
				 boolean i = isbn.isEmpty();
				 boolean n = bname.isEmpty();
				 
                 if(i==true || n==true)
					{
						showMessageDialog(null, "Insert Booklist","Warning", JOptionPane.WARNING_MESSAGE);
					}
					
                else
				{
              		try
						{
                            File file = new File(".\\File\\booklist.txt");//
                            if (!file.exists())
							{
                                file.createNewFile();
                            }
                            FileWriter f = new FileWriter(file, true);
                            BufferedWriter b = new BufferedWriter(f);
                            PrintWriter p = new PrintWriter(b);
			
							p.println("Name :" + bname);
							p.println("Isbn :"+ isbn);
                            p.close();
							showMessageDialog(null, "Added successfully","Warning", JOptionPane.WARNING_MESSAGE);

                        }
						catch (Exception ex)
						{
                            System.out.print(ex);
                        }
				}						
			}
		});
		
		insertB.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backpanel.add(insertB);
		
		
		
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
		frame.setResizable(false);
	}
	
	public static void main (String [] args )
	{
		new BookInfo();	
	}	
}